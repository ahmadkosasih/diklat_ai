# diklat_ai Package
A helper pip package for diklat_ai_kosasih

### Assumptions:
+ Assuming python is installed on your system.

Installation sets up command
**************************************

Situation before installation::

    $ diklat_ai_kosasih
    bash: diklat_ai_kosasih: command not found

Installation right from the source tree (or via pip from PyPI)::

    $ python setup.py install

    $ pip install diklat_ai_kosasih

Now, the ``diklat_ai_kosasih`` command is available::

    $ diklat_ai_kosasih
    Welcome to Diklat AI Kosasih. My name is Ahmad Kosasih!
    Aplikasi untuk menghitung Energi Foton
    Apakah Anda ingin menghitung Energi Foton? [Ya]/[Tidak] : _